/**
 * Solwin Infotech
 * Solwin Featured Product Extension
 * 
 * @category   Solwin
 * @package    Solwin_FeaturedPro
 * @copyright  Copyright © 2006-2016 Solwin (https://www.solwininfotech.com)
 * @license    https://www.solwininfotech.com/magento-extension-license/
 */

var config = {
    map: {
        '*': {
            cpowlcarousel: 'Solwin_FeaturedPro/js/owl.carousel'
        }
    }
};